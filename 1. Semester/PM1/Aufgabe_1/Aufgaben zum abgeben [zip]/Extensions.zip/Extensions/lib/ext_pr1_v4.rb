# EXTENSIONS FOR PR1 Jan. 2012
# ============================
# Michael Böhm 19.01.12

require "ext_checks_v1"
require "ext_elems_v2"
require "ext_modules_v2"
require "ext_lists_v2"

# INSTALLING THE EXTENSIONS
# =========================
# create a new project with name 'ext_pr1'
# copy the extension files to the source files of this project (drag and drop)

# USING THE THE EXTENSIONS
# ========================

# insert the following lines
# $LOAD_PATH.unshift File.join(File.dirname(__FILE__),'../..','ext_pr1/lib')
# require 'ext_pr1_v3'

