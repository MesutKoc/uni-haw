$LOAD_PATH.unshift File.join(File.dirname(__FILE__),'../..','Extensions/lib')
require 'ext_pr1_v4'

# Purpose:    Funktion die das Volumen eines Zylinders berechnet.
#             Die Argumente und das Resultat sollen Gleitkommazahlen sein.
# Contrackt:  zylinder_volume::=(radius,hoehe)
#             :: Float x Float -> Float :: ((radius, hoehe) >=0) 
#             :::: Math:PI * r**2 * h 
# Test:     {
#             [3.0,2.0] => 56.54867, [4.0,2.0] => 100.53096
#             [2.0,1.0] => 12.56637, [0.0, 0.0] => Err
#             ["z","t"] => Err, [2,4] => Err, [-2,1] => Err
#             [1,-2] => Err
#            }

def zylinder_volume(r, h)
  check_pre((r.float? and h.float?))
  check_pre(((r >=0) and (h >=0)))
  r**2 * h * Math::PI
end

