$LOAD_PATH.unshift File.join(File.dirname(__FILE__),'../..','Extensions/lib')
require 'ext_pr1_v4'

# Purpose:    Funktion schreiben, welches die Oberfläche eines Pentagondodekaeder berechnet.
#             Das Argument + Resultat werden Float sein.
# Contrackt:  Penta::=(a)
#             :: Float ->? Float :::: (3 * a**2 ) * FORMEL
# Test: {
#           [0.0] => Err, [1.0] => 20.64573, [2.0] => 82.58292, [3.0] => 557,43471, ['a'] => Err,
#           [-10]=> Err 
#       }

#globale oberflächen formel
FORMEL = Math.sqrt(25 + 10 * Math.sqrt(5))

def surface(a)
  check_pre((a.float?))
  check_pre((a >= 1.0))
  ( (3 * ( a**2 ) * FORMEL ) )
end
