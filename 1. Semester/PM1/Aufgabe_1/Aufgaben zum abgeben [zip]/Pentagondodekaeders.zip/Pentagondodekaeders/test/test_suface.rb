$:.unshift File.join(File.dirname(__FILE__),'..','lib')

require 'test/unit'
require 'o_pentagon'

class TestSuface < Test::Unit::TestCase
  def test_surface
    # positive tests
    assert_in_delta(20.64573,surface(1.0),0.001)
    assert_in_delta(82.58292,surface(2.0),0.001)
    assert_in_delta(185.81156,surface(3.0),0.001)
    
    # test illegal types
    assert_raise(RuntimeError) {surface(0.0)}
    assert_raise(RuntimeError) {surface("a")}
    
    # test illegal values of legal types
    assert_raise(RuntimeError) {surface(-10.0)}
  end
end
