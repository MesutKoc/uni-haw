$LOAD_PATH.unshift File.join(File.dirname(__FILE__),'../..','Extensions/lib') 
# INCLUDES FOR THE TASK 5
# ============================
# Mesut K., Anton K.
require 'ext_pr1_v4'

module Enumerable
  # Converts to array
  # Enumerable#to_a_ ::= Any -> Array
  # Tests: {...}
  def to_a_
    accu = []
    self.each{ |elem| accu << elem }
    #self.each_with_index { |obj| obj.to_a}
    accu
  end
  
  def to_a_; reduce([],:<<) end
  
  
  # map_
  # Enumerable#map_ ::= Any
  # Tests: {...}
  def map_
    accu = []
    self.each{ |item| accu << yield(item)}
    accu
  end
  
  # Enumerable#any_?
  # Tests: {...}
  def any_?(&block)
    check_pre(block_given?)
    bool = false
    self.each{ |elem| bool = (not(yield(elem) == nil or yield(elem) == false))}
    bool
  end
  
  # Enumerable#max_
  # Tests: {...}
   def max_(&block)
     arr = []
     ( not(block_given?) ? ( block = proc {|a,b| a <=> b}) : nil )
     self.each {|elem| arr << elem}
     s = arr.sort(&block).reverse.take(1)
     return s.join.to_s
   end
   
   def max_; reduce(:max) end
  
  # Enumerable#freq_count
  def freq_count
		hash = {}
		self.each { |item| (hash.has_key?(item))? hash[item] += 1 : hash[item] = 1}
		hash
	end
end
