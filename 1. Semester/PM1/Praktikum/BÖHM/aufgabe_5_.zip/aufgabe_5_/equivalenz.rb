$LOAD_PATH.unshift File.join(File.dirname(__FILE__),'../..','Extensions/lib') 
# INCLUDES FOR THE TASK 5
# ============================
# Mesut K., Anton K.
require 'ext_pr1_v4'

def_class(:FullName,[:first_name,:last_name]){
  include Comparable
  def invariant?
    self.first_name.string? and self.last_name.string?
  end
 
  def ==(obj)
    self.equal?(obj) or (obj.full_name? and (self.to_a == obj.to_a))
    #self.equal?(obj) or (obj.full_name? and self.first_name == obj.first_name and self.last_name  == obj.last_name)
  end
 
  def <=>(obj)
    if not(obj.full_name?) then return nil end
    val = (self.first_name <=> obj.first_name)
    if (val == 0) then self.last_name <=> obj.last_name else val end
  end
}

class Hash
  def ==(o)
    self.equal?(o) or 
      (o.hash? and self.size == o.size and self.include?(o))
  end
end











