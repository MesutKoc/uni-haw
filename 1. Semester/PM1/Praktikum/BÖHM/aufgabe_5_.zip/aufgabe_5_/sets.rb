$LOAD_PATH.unshift File.join(File.dirname(__FILE__),'../..','Extensions/lib') 
# INCLUDES FOR THE TASK 5
# ============================
# Mesut K., Anton K.
require 'ext_pr1_v4'

class Set
  # Function proof if a set in a other set 
  # Set#superset?(set) ::= Set x Set -> Bool
  # Tests: {...}
  def superset?(param_set)
    check_pre(param_set.set?)
    #param_set.to_a.each { |x| (self.to_a.include?(x)) ? true : false }
    param_set.to_a.reduce(true) {|accu, elem| (elem.in?(self)?(accu):(false))}
  end
  
  p 1.in?(Set[1,2])

  # Function proofs if the sets equal
  # Set #==(aSet) ::= Set x Any -> Bool
  # Tests: {...}
  def ==(o)
    self.equal?(o) or (o.set? and o.size == self.size and 
                          self.superset?(o) and o.superset?(self))
  end
end