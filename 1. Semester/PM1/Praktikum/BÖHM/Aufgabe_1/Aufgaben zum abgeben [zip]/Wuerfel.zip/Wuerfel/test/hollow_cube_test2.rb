# To change this license header, choose License Headers in Project Properties.
# To change this template file, choose Tools | Templates
# and open the template in the editor.

$:.unshift File.join(File.dirname(__FILE__),'..','lib')

require 'test/unit'
require 'hollow_cube_2'

class HollowCubeTest2 < Test::Unit::TestCase
   def test_hollow_cube_n
    # positive tests
    assert_equal(98,hohl_wuerfel_n(5,3,3))
    assert_equal(2882,hohl_wuerfel_n(5,3,5))
    
    # test illegal types
    assert_raise(RuntimeError) {hohl_wuerfel_n(2,5,4)}
    assert_raise(RuntimeError) {hohl_wuerfel_n("b","z","t")}
    assert_raise(RuntimeError) {hohl_wuerfel_n(0,0,0)}
    
    # test illegal values of legal types
    assert_raise(RuntimeError) {hohl_wuerfel_n(5,4,-1)}
    assert_raise(RuntimeError) {hohl_wuerfel_n(4,2,-2)}
  
  end
end
