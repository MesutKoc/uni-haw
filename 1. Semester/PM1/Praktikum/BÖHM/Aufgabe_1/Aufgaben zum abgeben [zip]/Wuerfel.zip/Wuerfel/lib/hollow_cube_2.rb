$LOAD_PATH.unshift File.join(File.dirname(__FILE__),'../..','Extensions/lib')
require 'ext_pr1_v4'

# Purpose:    Funktion erweitern, welches Volumen eines n-Hohlwürfels berechnet.
#             Argumente + Resultat sollen NAT sein.
# Contrackt:  hohl_wuerfel_n::=(l_außen,l_innen,n)
#             :: Nat x Nat ->? Nat :: ((l_außen >= l_innen) and (n>=3))
# Test: {
#         [5,4,-1] => Err, [2,3,5] => Err, [5,3,5] => 2882, [2,4,1] => Err,
#         [5,3,2] => 16, [-1,-1,-1] => Err, [0,0,0] => Err, [4,2,-2] => Err,
#         [2,5,4] => Err, ['b', 'z', 't'] => Err
#       }


def hohl_wuerfel_n(l_außen, l_innen, n)
  check_pre((l_außen.nat? and l_innen.nat? and n.nat?))
  check_pre(((l_außen >= l_innen) and (n >=3)))
  volume_of_n(l_außen, n) - volume_of_n(l_innen, n)
end

def volume_of_n(l, n)
  l**n
end



